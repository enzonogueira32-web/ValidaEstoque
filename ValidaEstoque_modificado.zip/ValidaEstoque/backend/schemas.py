from datetime import date
from pydantic import BaseModel


class UsuarioCreate(BaseModel):
    nome: str
    email: str
    senha: str


class UsuarioLogin(BaseModel):
    email: str
    senha: str


class UsuarioResponse(BaseModel):
    id: int
    nome: str
    email: str


class ProdutoCreate(BaseModel):
    nome: str
    categoria: str
    quantidade: int
    quantidade_minima: int
    data_validade: date
    preco: float