
from hashlib import sha256
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session

from .database import engine, Base
from . import models
from .schemas import ProdutoCreate, UsuarioCreate, UsuarioLogin, UsuarioResponse
from .regras import verificar_status, precisa_comprar
from fastapi.responses import HTMLResponse
from pathlib import Path

from datetime import date

app = FastAPI(title="ValidaEstoque")

Base.metadata.create_all(bind=engine)


def get_db():
    db = Session(bind=engine)

    try:
        yield db
    finally:
        db.close()


def gerar_hash_senha(senha: str) -> str:
    return sha256(senha.strip().encode("utf-8")).hexdigest()


@app.get("/", response_class=HTMLResponse)
def inicio():
    caminho = Path(__file__).parent / "index.html"
    return caminho.read_text(encoding="utf-8")


@app.post("/auth/register", response_model=UsuarioResponse)
def registrar_usuario(
    usuario: UsuarioCreate,
    db: Session = Depends(get_db)
):
    nome = usuario.nome.strip()
    email = usuario.email.strip().lower()

    if not nome or not email:
        raise HTTPException(status_code=400, detail="Nome e e-mail são obrigatórios")

    if len(usuario.senha.strip()) < 6:
        raise HTTPException(status_code=400, detail="A senha deve ter pelo menos 6 caracteres")

    usuario_existente = db.query(models.Usuario).filter(
        models.Usuario.email == email
    ).first()

    if usuario_existente is not None:
        raise HTTPException(status_code=400, detail="Este e-mail já está cadastrado")

    novo_usuario = models.Usuario(
        nome=nome,
        email=email,
        senha_hash=gerar_hash_senha(usuario.senha)
    )

    db.add(novo_usuario)
    db.commit()
    db.refresh(novo_usuario)

    return UsuarioResponse(
        id=novo_usuario.id,
        nome=novo_usuario.nome,
        email=novo_usuario.email
    )


@app.post("/auth/login", response_model=UsuarioResponse)
def login_usuario(
    dados: UsuarioLogin,
    db: Session = Depends(get_db)
):
    email = dados.email.strip().lower()
    usuario = db.query(models.Usuario).filter(
        models.Usuario.email == email
    ).first()

    if usuario is None or usuario.senha_hash != gerar_hash_senha(dados.senha):
        raise HTTPException(status_code=401, detail="E-mail ou senha inválidos")

    return UsuarioResponse(
        id=usuario.id,
        nome=usuario.nome,
        email=usuario.email
    )


@app.post("/produtos")
def criar_produto(
    produto: ProdutoCreate,
    db: Session = Depends(get_db)
):

    novo_produto = models.Produto(
        nome=produto.nome,
        categoria=produto.categoria,
        quantidade=produto.quantidade,
        quantidade_minima=produto.quantidade_minima,
        data_validade=produto.data_validade,
        preco=produto.preco
    )

    db.add(novo_produto)
    db.commit()
    db.refresh(novo_produto)

    return novo_produto


@app.get("/produtos")
def listar_produtos(
    db: Session = Depends(get_db)
):

    produtos = db.query(models.Produto).all()

    resultado = []

    for produto in produtos:

        resultado.append({
            "id": produto.id,
            "nome": produto.nome,
            "categoria": produto.categoria,
            "quantidade": produto.quantidade,
            "quantidade_minima": produto.quantidade_minima,
            "data_validade": produto.data_validade,
            "preco": produto.preco,
            "status": verificar_status(produto.data_validade),
            "precisa_comprar": precisa_comprar(
                produto.quantidade,
                produto.quantidade_minima
            )
        })

    return resultado


@app.get("/produtos/{produto_id}")
def buscar_produto(
    produto_id: int,
    db: Session = Depends(get_db)
):

    produto = db.query(models.Produto).filter(
        models.Produto.id == produto_id
    ).first()

    if produto is None:
        raise HTTPException(
            status_code=404,
            detail="Produto não encontrado"
        )

    return {
        "id": produto.id,
        "nome": produto.nome,
        "categoria": produto.categoria,
        "quantidade": produto.quantidade,
        "quantidade_minima": produto.quantidade_minima,
        "data_validade": produto.data_validade,
        "preco": produto.preco
    }


@app.put("/produtos/{produto_id}")
def atualizar_produto(
    produto_id: int,
    produto: ProdutoCreate,
    db: Session = Depends(get_db)
):

    produto_existente = db.query(models.Produto).filter(
        models.Produto.id == produto_id
    ).first()

    if produto_existente is None:
        raise HTTPException(
            status_code=404,
            detail="Produto não encontrado"
        )

    produto_existente.nome = produto.nome
    produto_existente.categoria = produto.categoria
    produto_existente.quantidade = produto.quantidade
    produto_existente.quantidade_minima = produto.quantidade_minima
    produto_existente.data_validade = produto.data_validade
    produto_existente.preco = produto.preco

    db.commit()
    db.refresh(produto_existente)

    return produto_existente


@app.delete("/produtos/{produto_id}")
def deletar_produto(
    produto_id: int,
    db: Session = Depends(get_db)
):

    produto = db.query(models.Produto).filter(
        models.Produto.id == produto_id
    ).first()

    if produto is None:
        raise HTTPException(
            status_code=404,
            detail="Produto não encontrado"
        )

    db.delete(produto)
    db.commit()

    return {
        "mensagem": "Produto deletado com sucesso"
    }


@app.get("/lista-compras")
def lista_compras(db: Session = Depends(get_db)):

    produtos = db.query(models.Produto).all()

    lista = []

    for produto in produtos:

        if precisa_comprar(
            produto.quantidade,
            produto.quantidade_minima
        ):

            lista.append({
                "id": produto.id,
                "nome": produto.nome,
                "quantidade": produto.quantidade,
                "quantidade_minima": produto.quantidade_minima,
                "quantidade_a_comprar":
                    produto.quantidade_minima - produto.quantidade
            })

    return lista


@app.get("/relatorio/vencidos")
def relatorio_vencidos(db: Session = Depends(get_db)):

    hoje = date.today()

    produtos = db.query(models.Produto).filter(
        models.Produto.data_validade < hoje
    ).all()

    resultado = []
    prejuizo_total = 0

    for produto in produtos:

        prejuizo = produto.quantidade * produto.preco
        prejuizo_total += prejuizo

        resultado.append({
            "id": produto.id,
            "nome": produto.nome,
            "quantidade": produto.quantidade,
            "preco": produto.preco,
            "prejuizo": prejuizo,
            "data_validade": produto.data_validade
        })

    return {
        "total_produtos_vencidos": len(resultado),
        "produtos_vencidos": resultado,
        "prejuizo_total": prejuizo_total
    }


@app.get("/relatorio/vencendo")
def relatorio_vencendo(db: Session = Depends(get_db)):

    produtos = db.query(models.Produto).all()

    resultado = []

    for produto in produtos:

        if verificar_status(produto.data_validade) == "vence_em_breve":

            dias_restantes = (
                produto.data_validade - date.today()
            ).days

            resultado.append({
                "id": produto.id,
                "nome": produto.nome,
                "categoria": produto.categoria,
                "quantidade": produto.quantidade,
                "data_validade": produto.data_validade,
                "dias_restantes": dias_restantes,
                "preco": produto.preco
            })

    return {
        "total": len(resultado),
        "produtos": resultado
    }


@app.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):

    produtos = db.query(models.Produto).all()

    vencidos = 0
    vencendo_em_breve = 0
    seguros = 0
    estoque_baixo = 0
    prejuizo = 0

    for produto in produtos:

        status = verificar_status(produto.data_validade)

        if status == "vencido":
            vencidos += 1
            prejuizo += produto.quantidade * produto.preco

        elif status == "vence_em_breve":
            vencendo_em_breve += 1

        else:
            seguros += 1

        if precisa_comprar(
            produto.quantidade,
            produto.quantidade_minima
        ):
            estoque_baixo += 1

    return {
        "total_produtos": len(produtos),
        "produtos_vencidos": vencidos,
        "produtos_vencendo_em_breve": vencendo_em_breve,
        "produtos_seguros": seguros,
        "produtos_com_estoque_baixo": estoque_baixo,
        "prejuizo_com_produtos_vencidos": prejuizo
    }


@app.get("/relatorio/estoque-baixo")
def relatorio_estoque_baixo(db: Session = Depends(get_db)):

    produtos = db.query(models.Produto).all()

    resultado = []

    for produto in produtos:

        if precisa_comprar(
            produto.quantidade,
            produto.quantidade_minima
        ):

            quantidade_a_comprar = (
                produto.quantidade_minima - produto.quantidade
            )

            resultado.append({
                "id": produto.id,
                "nome": produto.nome,
                "categoria": produto.categoria,
                "quantidade_atual": produto.quantidade,
                "quantidade_minima": produto.quantidade_minima,
                "quantidade_a_comprar": quantidade_a_comprar,
                "preco": produto.preco
            })

    return {
        "total": len(resultado),
        "produtos": resultado
    }


@app.get("/resumo")
def resumo(db: Session = Depends(get_db)):

    produtos = db.query(models.Produto).all()

    valor_total_estoque = 0
    produtos_vencidos = 0
    produtos_vencendo = 0
    produtos_estoque_baixo = 0

    for produto in produtos:

        valor_total_estoque += (
            produto.quantidade * produto.preco
        )

        status = verificar_status(produto.data_validade)

        if status == "vencido":
            produtos_vencidos += 1

        elif status == "vence_em_breve":
            produtos_vencendo += 1

        if precisa_comprar(
            produto.quantidade,
            produto.quantidade_minima
        ):
            produtos_estoque_baixo += 1

    return {
        "total_produtos": len(produtos),
        "valor_total_estoque": valor_total_estoque,
        "produtos_vencidos": produtos_vencidos,
        "produtos_vencendo_em_breve": produtos_vencendo,
        "produtos_com_estoque_baixo": produtos_estoque_baixo
    }
